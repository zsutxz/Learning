#!/bin/bash

set -ev

go get github.com/google/gopacket
go get github.com/google/gopacket/layers
go get github.com/google/gopacket/tcpassembly
go get github.com/google/gopacket/reassembly
go get github.com/google/gopacket/pcapgo
